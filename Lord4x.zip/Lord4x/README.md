# ⚔️ Lord4x — Network Analysis Suite

> Mobile-first network analysis & security toolkit — PWA (Progressive Web App)

![Version](https://img.shields.io/badge/version-1.0.0-00f5d4?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-a855f7?style=flat-square)
![PWA](https://img.shields.io/badge/PWA-ready-00ff88?style=flat-square)

---

## 📲 Install on Your Phone

1. Open `index.html` in your phone browser (or host it)
2. A banner will appear: **"INSTALL LORD4X"**
3. Tap **INSTALL** → Add to home screen
4. Done! Lord4x is now installed like a native app ✅

> **iOS (Safari):** Tap Share → "Add to Home Screen"  
> **Android (Chrome):** Tap the install banner or Menu → "Add to Home Screen"

---

## ✨ Features

| Tool | Description |
|------|-------------|
| ⚡ Quick Scan | Fast single-target network scan |
| 🔍 Port Scanner | TCP port scan with service detection |
| 📶 Ping & Trace | Ping test + traceroute visualization |
| 🌐 WHOIS | Domain/IP registration lookup |
| 🔗 DNS Lookup | DNS record resolver (A, AAAA, MX, TXT) |
| 🧮 Subnet Calc | IP/CIDR subnet calculator |
| 📡 HTTP Headers | Web server header inspection |
| 🔒 MAC Lookup | Hardware vendor identification |
| 🗺️ Geo IP | IP geolocation tracer |

---

## 🗂 File Structure

```
Lord4x/
├── index.html      ← Main app (single file)
├── manifest.json   ← PWA manifest
├── sw.js           ← Service worker (offline support)
├── icon-192.png    ← App icon (192×192) — add your own
├── icon-512.png    ← App icon (512×512) — add your own
└── README.md       ← This file
```

---

## 🚀 Quick Start (Local)

```bash
# Python 3
python3 -m http.server 8080

# Node.js
npx serve .
```

Then open: `http://localhost:8080`

---

## 🛠 Tech Stack

- **HTML5** / **CSS3** / **Vanilla JS** — zero dependencies
- **PWA** — Service Worker + Web App Manifest
- **Fonts:** Orbitron, Rajdhani, Share Tech Mono (Google Fonts)

---

## 📝 License

MIT License — free to use, modify, and distribute.

---

## 🤝 Contributing

1. Fork the repo
2. Create your branch: `git checkout -b feature/my-feature`
3. Commit: `git commit -m 'Add my feature'`
4. Push: `git push origin feature/my-feature`
5. Open a Pull Request

Ideas welcome: new tools, UI improvements, real API integrations, dark/light themes, etc.

---

*Built with ⚔️ by the open source community*
